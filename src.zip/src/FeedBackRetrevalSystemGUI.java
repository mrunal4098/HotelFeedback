import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

public class FeedbackRetrievalSystemGUI {
    private JFrame frame;
    private JTextField customerIdField;
    private JTextField customerNameField;
    private JTextField customerEmailField;
    private JTextField feedbackIdField;
    private JTextField feedbackCustomerIdField;
    private JTextField feedbackHotelIdField;
    private JTextField feedbackMessageField;
    private JTextField hotelIdField;
    private JTextField hotelNameField;
    private JTextField hotelLocationField;
    private JTextField hotelContactField;
    private JTextField cleanlinessRatingField;
    private JTextField serviceRatingField;
    private JTextArea resultArea;

    private Connection connection;
    private Statement statement;

    public FeedbackRetrievalSystemGUI() {
        initialize();
        connectToDatabase();
    }

    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        // Customer Section
        JLabel lblCustomerId = new JLabel("Customer ID:");
        lblCustomerId.setBounds(20, 20, 100, 20);
        frame.getContentPane().add(lblCustomerId);

        customerIdField = new JTextField();
        customerIdField.setBounds(130, 20, 150, 20);
        frame.getContentPane().add(customerIdField);

        JLabel lblCustomerName = new JLabel("Name:");
        lblCustomerName.setBounds(20, 50, 100, 20);
        frame.getContentPane().add(lblCustomerName);

        customerNameField = new JTextField();
        customerNameField.setBounds(130, 50, 150, 20);
        frame.getContentPane().add(customerNameField);

        JLabel lblCustomerEmail = new JLabel("Email:");
        lblCustomerEmail.setBounds(20, 80, 100, 20);
        frame.getContentPane().add(lblCustomerEmail);

        customerEmailField = new JTextField();
        customerEmailField.setBounds(130, 80, 150, 20);
        frame.getContentPane().add(customerEmailField);

        JButton btnSubmitCustomer = new JButton("Submit");
        btnSubmitCustomer.setBounds(130, 110, 100, 25);
        btnSubmitCustomer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                insertCustomer();
            }
        });
        frame.getContentPane().add(btnSubmitCustomer);

        // Feedback Section
        JLabel lblFeedbackId = new JLabel("Feedback ID:");
        lblFeedbackId.setBounds(20, 150, 100, 20);
        frame.getContentPane().add(lblFeedbackId);

        feedbackIdField = new JTextField();
        feedbackIdField.setBounds(130, 150, 150, 20);
        frame.getContentPane().add(feedbackIdField);

        JLabel lblFeedbackCustomerId = new JLabel("Customer ID:");
        lblFeedbackCustomerId.setBounds(20, 180, 100, 20);
        frame.getContentPane().add(lblFeedbackCustomerId);

        feedbackCustomerIdField = new JTextField();
        feedbackCustomerIdField.setBounds(130, 180, 150, 20);
        frame.getContentPane().add(feedbackCustomerIdField);

        JLabel lblFeedbackHotelId = new JLabel("Hotel ID:");
        lblFeedbackHotelId.setBounds(20, 210, 100, 20);
        frame.getContentPane().add(lblFeedbackHotelId);

        feedbackHotelIdField = new JTextField();
        feedbackHotelIdField.setBounds(130, 210, 150, 20);
        frame.getContentPane().add(feedbackHotelIdField);

        JLabel lblFeedbackMessage = new JLabel("Message:");
        lblFeedbackMessage.setBounds(20, 240, 100, 20);
        frame.getContentPane().add(lblFeedbackMessage);

        feedbackMessageField = new JTextField();
        feedbackMessageField.setBounds(130, 240, 150, 20);
        frame.getContentPane().add(feedbackMessageField);

        JButton btnSubmitFeedback = new JButton("Submit");
        btnSubmitFeedback.setBounds(130, 270, 100, 25);
        btnSubmitFeedback.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                insertFeedback();
            }
        });
        frame.getContentPane().add(btnSubmitFeedback);

        // Hotel Section
        JLabel lblHotelId = new JLabel("Hotel ID:");
        lblHotelId.setBounds(20, 310, 100, 20);
        frame.getContentPane().add(lblHotelId);

        hotelIdField = new JTextField();
        hotelIdField.setBounds(130, 310, 150, 20);
        frame.getContentPane().add(hotelIdField);

        JLabel lblHotelName = new JLabel("Name:");
        lblHotelName.setBounds(20, 340, 100, 20);
        frame.getContentPane().add(lblHotelName);

        hotelNameField = new JTextField();
        hotelNameField.setBounds(130, 340, 150, 20);
        frame.getContentPane().add(hotelNameField);

        JLabel lblHotelLocation = new JLabel("Location:");
        lblHotelLocation.setBounds(20, 370, 100, 20);
        frame.getContentPane().add(lblHotelLocation);

        hotelLocationField = new JTextField();
        hotelLocationField.setBounds(130, 370, 150, 20);
        frame.getContentPane().add(hotelLocationField);

        JLabel lblHotelContact = new JLabel("Contact:");
        lblHotelContact.setBounds(20, 400, 100, 20);
        frame.getContentPane().add(lblHotelContact);

        hotelContactField = new JTextField();
        hotelContactField.setBounds(130, 400, 150, 20);
        frame.getContentPane().add(hotelContactField);

        JButton btnSubmitHotel = new JButton("Submit");
        btnSubmitHotel.setBounds(130, 430, 100, 25);
        btnSubmitHotel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                insertHotel();
            }
        });
        frame.getContentPane().add(btnSubmitHotel);

        // Rating Section
        JLabel lblCleanlinessRating = new JLabel("Cleanliness Rating:");
        lblCleanlinessRating.setBounds(20, 470, 150, 20);
        frame.getContentPane().add(lblCleanlinessRating);

        cleanlinessRatingField = new JTextField();
        cleanlinessRatingField.setBounds(160, 470, 120, 20);
        frame.getContentPane().add(cleanlinessRatingField);

        JLabel lblServiceRating = new JLabel("Service Rating:");
        lblServiceRating.setBounds(20, 500, 150, 20);
        frame.getContentPane().add(lblServiceRating);

        serviceRatingField = new JTextField();
        serviceRatingField.setBounds(160, 500, 120, 20);
        frame.getContentPane().add(serviceRatingField);

        JButton btnSubmitRating = new JButton("Submit");
        btnSubmitRating.setBounds(130, 530, 100, 25);
        btnSubmitRating.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                insertRating();
            }
        });
        frame.getContentPane().add(btnSubmitRating);

        // Result Area
        JLabel lblResult = new JLabel("Result:");
        lblResult.setBounds(350, 20, 100, 20);
        frame.getContentPane().add(lblResult);

        resultArea = new JTextArea();
        resultArea.setBounds(350, 50, 400, 520);
        frame.getContentPane().add(resultArea);

        JButton btnGetTopRatedHotels = new JButton("Get Top Rated Hotels");
       btnGetTopRatedHotels.setBounds(350, 580, 180, 25);
        btnGetTopRatedHotels.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                getTopRatedHotels();
            }
        });
        frame.getContentPane().add(btnGetTopRatedHotels);

        JButton btnGetAllHotels = new JButton("Get All Hotels");
        btnGetAllHotels.setBounds(570, 580, 180, 25);
        btnGetAllHotels.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                getAllHotels();
            }
        });
        frame.getContentPane().add(btnGetAllHotels);
    }

    private void connectToDatabase() {
        String url = "jdbc:oracle:thin:@localhost:1521:xe";
        String username = "mrunal";
        String password = "mrunal";

        try {
            connection = DriverManager.getConnection(url, username, password);
            statement = connection.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "passed to connect to the database.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void insertCustomer() {
        int customerId = Integer.parseInt(customerIdField.getText());
        String name = customerNameField.getText();
        String email = customerEmailField.getText();

        String query = "INSERT INTO customer (customer_id, name, email) VALUES (" + customerId + ", '" + name + "', '" + email + "')";

        try {
            statement.executeUpdate(query);
            JOptionPane.showMessageDialog(frame, "Customer inserted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "passed to insert customer.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void insertFeedback() {
        int feedbackId = Integer.parseInt(feedbackIdField.getText());
        int customerId = Integer.parseInt(feedbackCustomerIdField.getText());
        int hotelId = Integer.parseInt(feedbackHotelIdField.getText());
        String message = feedbackMessageField.getText();

        String query = "INSERT INTO feedback (feedback_id, customer_id, hotel_id, message) VALUES (" + feedbackId + ", " + customerId + ", " + hotelId + ", '" + message + "')";

        try {
            statement.executeUpdate(query);
            JOptionPane.showMessageDialog(frame, "Feedback inserted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "passed to insert feedback.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void insertHotel() {
        int hotelId = Integer.parseInt(hotelIdField.getText());
        String name = hotelNameField.getText();
        String location = hotelLocationField.getText();
        String contact = hotelContactField.getText();

        String query = "INSERT INTO hotel (hotel_id, name, location, contact) VALUES (" + hotelId + ", '" + name + "', '" + location + "', '" + contact + "')";

        try {
            statement.executeUpdate(query);
            JOptionPane.showMessageDialog(frame, "Hotel inserted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "passed to insert hotel.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void insertRating() {
        int customerId = Integer.parseInt(customerIdField.getText());
        int hotelId = Integer.parseInt(hotelIdField.getText());
        float cleanlinessRating = Float.parseFloat(cleanlinessRatingField.getText());
        float serviceRating = Float.parseFloat(serviceRatingField.getText());

        String query = "INSERT INTO rating (customer_id, hotel_id, cleanliness_rating, service_rating) VALUES (" + customerId + ", " + hotelId + ", " + cleanlinessRating + ", " + serviceRating + ")";

        try {
            statement.executeUpdate(query);
            JOptionPane.showMessageDialog(frame, "Rating inserted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "passed to insert rating.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void getTopRatedHotels() {
        String query = "SELECT h.hotel_id, h.name, h.location, h.contact, AVG(r.cleanliness_rating + r.service_rating) AS avg_rating " +
                "FROM hotel h JOIN rating r ON h.hotel_id = r.hotel_id " +
                "GROUP BY h.hotel_id " +
                "ORDER BY avg_rating DESC";

        try {
            ResultSet resultSet = statement.executeQuery(query);

            // Displaying the result in the resultArea
            resultArea.setText("");
            while (resultSet.next()) {
                int hotelId = resultSet.getInt("hotel_id");
                String name = resultSet.getString("name");
                String location = resultSet.getString("location");
                String contact = resultSet.getString("contact");
                double averageRating = resultSet.getDouble("avg_rating");

                resultArea.append("Hotel ID: " + hotelId + "\n");
                resultArea.append("Name: " + name + "\n");
                resultArea.append("Location: " + location + "\n");
                resultArea.append("Contact: " + contact + "\n");
                resultArea.append("Average Rating: " + averageRating + "\n");
                resultArea.append("\n");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "passed to get top rated hotels.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void getAllHotels() {
        String query = "SELECT * FROM hotel";

        try {
            ResultSet resultSet = statement.executeQuery(query);

            // Displaying the result in the resultArea
            resultArea.setText("");
            while (resultSet.next()) {
                int hotelId = resultSet.getInt("hotel_id");
                String name = resultSet.getString("name");
                String location = resultSet.getString("location");
                String contact = resultSet.getString("contact");

                resultArea.append("Hotel ID: " + hotelId + "\n");
                resultArea.append("Name: " + name + "\n");
                resultArea.append("Location: " + location + "\n");
                resultArea.append("Contact: " + contact + "\n");
                resultArea.append("\n");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "passed to get all hotels.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    FeedbackRetrievalSystemGUI window = new FeedbackRetrievalSystemGUI();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
